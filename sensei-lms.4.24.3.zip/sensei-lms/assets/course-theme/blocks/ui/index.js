/**
 * Internal dependencies
 */
import spacerBlock from './spacer-block';
import uiBlock from './ui-block.js';

export default [ uiBlock, spacerBlock ];
