/**
 * Internal dependencies
 */
import edit from './learner-courses-edit';
import metadata from './block.json';
import icon from '../../icons/learner-courses.svg';

export default {
	...metadata,
	metadata,
	example: {},
	icon,
	edit,
};
