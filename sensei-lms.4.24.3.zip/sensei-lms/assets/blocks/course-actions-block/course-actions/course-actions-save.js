/**
 * WordPress dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

export default function saveCourseActionsBlock() {
	return <InnerBlocks.Content />;
}
