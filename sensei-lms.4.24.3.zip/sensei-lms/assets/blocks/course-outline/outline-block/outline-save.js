/**
 * WordPress dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

const OutlineSave = () => <InnerBlocks.Content />;

export default OutlineSave;
