jQuery( document ).ready( function () {
	/***************************************************************************************************
	 * 	1 - Helper Functions.
	 ***************************************************************************************************/

	// Load the My Courses tab switcher
	jQuery( '#my-courses' ).tabs();
	jQuery( '#my-courses' ).removeClass( 'ui-corner-all' );
	jQuery( '#my-courses ul' ).removeClass( 'ui-corner-all' );
} );
