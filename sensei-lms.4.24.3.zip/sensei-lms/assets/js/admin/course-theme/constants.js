export const SENSEI_THEME = 'sensei-theme';
export const WORDPRESS_THEME = 'wordpress-theme';
export const SENSEI_PREVIEW_QUERY = 'sensei_theme_preview';
