export const HOME_PATH = 'admin.php?page=sensei';
