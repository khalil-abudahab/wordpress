/**
 * Internal dependencies
 */
import SingleLineInput from './single-line-input';

export default SingleLineInput;
