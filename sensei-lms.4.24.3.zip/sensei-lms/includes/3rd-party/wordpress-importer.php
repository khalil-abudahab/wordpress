<?php
/**
 * Adds additional compatibility with WordPress Importer.
 *
 * @package 3rd-Party
 * @deprecated 3.5.0
 */

_deprecated_file( __FILE__, '3.5.0' );
