<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: //codex.wordpress.org/Template_Hierarchy
 *
 * @package DENTARIO
 * @since DENTARIO 1.0
 */

$dentario_template = apply_filters( 'dentario_filter_get_template_part', dentario_blog_archive_get_template() );

if ( ! empty( $dentario_template ) && 'index' != $dentario_template ) {

	get_template_part( $dentario_template );

} else {

	dentario_storage_set( 'blog_archive', true );

	get_header();

	if ( have_posts() ) {

		// Query params
		$dentario_stickies   = is_home()
								|| ( in_array( dentario_get_theme_option( 'post_type' ), array( '', 'post' ) )
									&& (int) dentario_get_theme_option( 'parent_cat' ) == 0
									)
										? get_option( 'sticky_posts' )
										: false;
		$dentario_post_type  = dentario_get_theme_option( 'post_type' );
		$dentario_args       = array(
								'blog_style'     => dentario_get_theme_option( 'blog_style' ),
								'post_type'      => $dentario_post_type,
								'taxonomy'       => dentario_get_post_type_taxonomy( $dentario_post_type ),
								'parent_cat'     => dentario_get_theme_option( 'parent_cat' ),
								'posts_per_page' => dentario_get_theme_option( 'posts_per_page' ),
								'sticky'         => dentario_get_theme_option( 'sticky_style', 'inherit' ) == 'columns'
															&& is_array( $dentario_stickies )
															&& count( $dentario_stickies ) > 0
															&& get_query_var( 'paged' ) < 1
								);

		dentario_blog_archive_start();

		do_action( 'dentario_action_blog_archive_start' );

		if ( is_author() ) {
			do_action( 'dentario_action_before_page_author' );
			get_template_part( apply_filters( 'dentario_filter_get_template_part', 'templates/author-page' ) );
			do_action( 'dentario_action_after_page_author' );
		}

		if ( dentario_get_theme_option( 'show_filters', 0 ) ) {
			do_action( 'dentario_action_before_page_filters' );
			dentario_show_filters( $dentario_args );
			do_action( 'dentario_action_after_page_filters' );
		} else {
			do_action( 'dentario_action_before_page_posts' );
			dentario_show_posts( array_merge( $dentario_args, array( 'cat' => $dentario_args['parent_cat'] ) ) );
			do_action( 'dentario_action_after_page_posts' );
		}

		do_action( 'dentario_action_blog_archive_end' );

		dentario_blog_archive_end();

	} else {

		if ( is_search() ) {
			get_template_part( apply_filters( 'dentario_filter_get_template_part', 'templates/content', 'none-search' ), 'none-search' );
		} else {
			get_template_part( apply_filters( 'dentario_filter_get_template_part', 'templates/content', 'none-archive' ), 'none-archive' );
		}
	}

	get_footer();
}
