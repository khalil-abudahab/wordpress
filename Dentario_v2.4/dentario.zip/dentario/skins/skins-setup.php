<?php
/**
 * This file is NOT updated when the theme engine is updated
 * and contains features that affect all skins in the theme lineup.
 *
 * @package DENTARIO
 * @since DENTARIO 3.5.0
 */

