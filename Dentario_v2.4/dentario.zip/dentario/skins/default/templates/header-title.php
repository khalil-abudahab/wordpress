<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package DENTARIO
 * @since DENTARIO 1.0
 */

// Page (category, tag, archive, author) title

if ( dentario_need_page_title() ) {
	dentario_sc_layouts_showed( 'title', true );
	dentario_sc_layouts_showed( 'postmeta', true );
	?>
	<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Post meta on the single post
						if ( is_single() ) {
							?>
							<div class="sc_layouts_title_meta">
							<?php
								dentario_show_post_meta(
									apply_filters(
										'dentario_filter_post_meta_args', array(
											'components' => join( ',', dentario_array_get_keys_by_value( dentario_get_theme_option( 'meta_parts' ) ) ),
											'counters'   => join( ',', dentario_array_get_keys_by_value( dentario_get_theme_option( 'counters' ) ) ),
											'seo'        => dentario_is_on( dentario_get_theme_option( 'seo_snippets' ) ),
										), 'header', 1
									)
								);
							?>
							</div>
							<?php
						}

						// Blog/Post title
						?>
						<div class="sc_layouts_title_title">
							<?php
							$dentario_blog_title           = dentario_get_blog_title();
							$dentario_blog_title_text      = '';
							$dentario_blog_title_class     = '';
							$dentario_blog_title_link      = '';
							$dentario_blog_title_link_text = '';
							if ( is_array( $dentario_blog_title ) ) {
								$dentario_blog_title_text      = $dentario_blog_title['text'];
								$dentario_blog_title_class     = ! empty( $dentario_blog_title['class'] ) ? ' ' . $dentario_blog_title['class'] : '';
								$dentario_blog_title_link      = ! empty( $dentario_blog_title['link'] ) ? $dentario_blog_title['link'] : '';
								$dentario_blog_title_link_text = ! empty( $dentario_blog_title['link_text'] ) ? $dentario_blog_title['link_text'] : '';
							} else {
								$dentario_blog_title_text = $dentario_blog_title;
							}
							?>
							<h1 class="sc_layouts_title_caption<?php echo esc_attr( $dentario_blog_title_class ); ?>"<?php
								if ( dentario_is_on( dentario_get_theme_option( 'seo_snippets' ) ) ) {
									?> itemprop="headline"<?php
								}
							?>>
								<?php
								$dentario_top_icon = dentario_get_term_image_small();
								if ( ! empty( $dentario_top_icon ) ) {
									$dentario_attr = dentario_getimagesize( $dentario_top_icon );
									?>
									<img src="<?php echo esc_url( $dentario_top_icon ); ?>" alt="<?php esc_attr_e( 'Site icon', 'dentario' ); ?>"
										<?php
										if ( ! empty( $dentario_attr[3] ) ) {
											dentario_show_layout( $dentario_attr[3] );
										}
										?>
									>
									<?php
								}
								echo wp_kses_data( $dentario_blog_title_text );
								?>
							</h1>
							<?php
							if ( ! empty( $dentario_blog_title_link ) && ! empty( $dentario_blog_title_link_text ) ) {
								?>
								<a href="<?php echo esc_url( $dentario_blog_title_link ); ?>" class="theme_button theme_button_small sc_layouts_title_link"><?php echo esc_html( $dentario_blog_title_link_text ); ?></a>
								<?php
							}

							// Category/Tag description
							if ( ! is_paged() && ( is_category() || is_tag() || is_tax() ) ) {
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
							}

							?>
						</div>
						<?php

						// Breadcrumbs
						ob_start();
						do_action( 'dentario_action_breadcrumbs' );
						$dentario_breadcrumbs = ob_get_contents();
						ob_end_clean();
						dentario_show_layout( $dentario_breadcrumbs, '<div class="sc_layouts_title_breadcrumbs">', '</div>' );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
