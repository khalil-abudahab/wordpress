<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package DENTARIO
 * @since DENTARIO 1.0
 */

$dentario_template_args = get_query_var( 'dentario_template_args' );

if ( is_array( $dentario_template_args ) ) {
	$dentario_columns    = empty( $dentario_template_args['columns'] ) ? 2 : max( 1, $dentario_template_args['columns'] );
	$dentario_blog_style = array( $dentario_template_args['type'], $dentario_columns );
    $dentario_columns_class = dentario_get_column_class( 1, $dentario_columns, ! empty( $dentario_template_args['columns_tablet']) ? $dentario_template_args['columns_tablet'] : '', ! empty($dentario_template_args['columns_mobile']) ? $dentario_template_args['columns_mobile'] : '' );
} else {
	$dentario_template_args = array();
	$dentario_blog_style = explode( '_', dentario_get_theme_option( 'blog_style' ) );
	$dentario_columns    = empty( $dentario_blog_style[1] ) ? 2 : max( 1, $dentario_blog_style[1] );
    $dentario_columns_class = dentario_get_column_class( 1, $dentario_columns );
}
$dentario_expanded   = ! dentario_sidebar_present() && dentario_get_theme_option( 'expand_content' ) == 'expand';

$dentario_post_format = get_post_format();
$dentario_post_format = empty( $dentario_post_format ) ? 'standard' : str_replace( 'post-format-', '', $dentario_post_format );

?><div class="<?php
	if ( ! empty( $dentario_template_args['slider'] ) ) {
		echo ' slider-slide swiper-slide';
	} else {
		echo ( dentario_is_blog_style_use_masonry( $dentario_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $dentario_columns ) : esc_attr( $dentario_columns_class ) );
	}
?>"><article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $dentario_post_format )
				. ' post_layout_classic post_layout_classic_' . esc_attr( $dentario_columns )
				. ' post_layout_' . esc_attr( $dentario_blog_style[0] )
				. ' post_layout_' . esc_attr( $dentario_blog_style[0] ) . '_' . esc_attr( $dentario_columns )
	);
	dentario_add_blog_animation( $dentario_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$dentario_hover      = ! empty( $dentario_template_args['hover'] ) && ! dentario_is_inherit( $dentario_template_args['hover'] )
							? $dentario_template_args['hover']
							: dentario_get_theme_option( 'image_hover' );

	$dentario_components = ! empty( $dentario_template_args['meta_parts'] )
							? ( is_array( $dentario_template_args['meta_parts'] )
								? $dentario_template_args['meta_parts']
								: explode( ',', $dentario_template_args['meta_parts'] )
								)
							: dentario_array_get_keys_by_value( dentario_get_theme_option( 'meta_parts' ) );

	dentario_show_post_featured( apply_filters( 'dentario_filter_args_featured',
		array(
			'thumb_size' => ! empty( $dentario_template_args['thumb_size'] )
				? $dentario_template_args['thumb_size']
				: dentario_get_thumb_size(
					'classic' == $dentario_blog_style[0]
						? ( strpos( dentario_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $dentario_columns > 2 ? 'big' : 'huge' )
								: ( $dentario_columns > 2
									? ( $dentario_expanded ? 'square' : 'square' )
									: ($dentario_columns > 1 ? 'square' : ( $dentario_expanded ? 'huge' : 'big' ))
									)
							)
						: ( strpos( dentario_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $dentario_columns > 2 ? 'masonry-big' : 'full' )
								: ($dentario_columns === 1 ? ( $dentario_expanded ? 'huge' : 'big' ) : ( $dentario_columns <= 2 && $dentario_expanded ? 'masonry-big' : 'masonry' ))
							)
			),
			'hover'      => $dentario_hover,
			'meta_parts' => $dentario_components,
			'no_links'   => ! empty( $dentario_template_args['no_links'] ),
        ),
        'content-classic',
        $dentario_template_args
    ) );

	// Title and post meta
	$dentario_show_title = get_the_title() != '';
	$dentario_show_meta  = count( $dentario_components ) > 0 && ! in_array( $dentario_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );

	if ( $dentario_show_title ) {
		?>
		<div class="post_header entry-header">
			<?php

			// Post meta
			if ( apply_filters( 'dentario_filter_show_blog_meta', $dentario_show_meta, $dentario_components, 'classic' ) ) {
				if ( count( $dentario_components ) > 0 ) {
					do_action( 'dentario_action_before_post_meta' );
					dentario_show_post_meta(
						apply_filters(
							'dentario_filter_post_meta_args', array(
							'components' => join( ',', $dentario_components ),
							'seo'        => false,
							'echo'       => true,
						), $dentario_blog_style[0], $dentario_columns
						)
					);
					do_action( 'dentario_action_after_post_meta' );
				}
			}

			// Post title
			if ( apply_filters( 'dentario_filter_show_blog_title', true, 'classic' ) ) {
				do_action( 'dentario_action_before_post_title' );
				if ( empty( $dentario_template_args['no_links'] ) ) {
					the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );
				} else {
					the_title( '<h4 class="post_title entry-title">', '</h4>' );
				}
				do_action( 'dentario_action_after_post_title' );
			}

			if( !in_array( $dentario_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
				// More button
				if ( apply_filters( 'dentario_filter_show_blog_readmore', ! $dentario_show_title || ! empty( $dentario_template_args['more_button'] ), 'classic' ) ) {
					if ( empty( $dentario_template_args['no_links'] ) ) {
						do_action( 'dentario_action_before_post_readmore' );
						dentario_show_post_more_link( $dentario_template_args, '<div class="more-wrap">', '</div>' );
						do_action( 'dentario_action_after_post_readmore' );
					}
				}
			}
			?>
		</div><!-- .entry-header -->
		<?php
	}

	// Post content
	if( in_array( $dentario_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
		ob_start();
		if (apply_filters('dentario_filter_show_blog_excerpt', empty($dentario_template_args['hide_excerpt']) && dentario_get_theme_option('excerpt_length') > 0, 'classic')) {
			dentario_show_post_content($dentario_template_args, '<div class="post_content_inner">', '</div>');
		}
		// More button
		if(! empty( $dentario_template_args['more_button'] )) {
			if ( empty( $dentario_template_args['no_links'] ) ) {
				do_action( 'dentario_action_before_post_readmore' );
				dentario_show_post_more_link( $dentario_template_args, '<div class="more-wrap">', '</div>' );
				do_action( 'dentario_action_after_post_readmore' );
			}
		}
		$dentario_content = ob_get_contents();
		ob_end_clean();
		dentario_show_layout($dentario_content, '<div class="post_content entry-content">', '</div><!-- .entry-content -->');
	}
	?>

</article></div><?php
// Need opening PHP-tag above, because <div> is a inline-block element (used as column)!
