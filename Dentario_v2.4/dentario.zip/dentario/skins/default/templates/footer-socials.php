<?php
/**
 * The template to display the socials in the footer
 *
 * @package DENTARIO
 * @since DENTARIO 1.0.10
 */


// Socials
if ( dentario_is_on( dentario_get_theme_option( 'socials_in_footer' ) ) ) {
	$dentario_output = dentario_get_socials_links();
	if ( '' != $dentario_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php dentario_show_layout( $dentario_output ); ?>
			</div>
		</div>
		<?php
	}
}
