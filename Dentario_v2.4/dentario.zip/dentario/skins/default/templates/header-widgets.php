<?php
/**
 * The template to display the widgets area in the header
 *
 * @package DENTARIO
 * @since DENTARIO 1.0
 */

// Header sidebar
$dentario_header_name    = dentario_get_theme_option( 'header_widgets' );
$dentario_header_present = ! dentario_is_off( $dentario_header_name ) && is_active_sidebar( $dentario_header_name );
if ( $dentario_header_present ) {
	dentario_storage_set( 'current_sidebar', 'header' );
	$dentario_header_wide = dentario_get_theme_option( 'header_wide' );
	ob_start();
	if ( is_active_sidebar( $dentario_header_name ) ) {
		dynamic_sidebar( $dentario_header_name );
	}
	$dentario_widgets_output = ob_get_contents();
	ob_end_clean();
	if ( ! empty( $dentario_widgets_output ) ) {
		$dentario_widgets_output = preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $dentario_widgets_output );
		$dentario_need_columns   = strpos( $dentario_widgets_output, 'columns_wrap' ) === false;
		if ( $dentario_need_columns ) {
			$dentario_columns = max( 0, (int) dentario_get_theme_option( 'header_columns' ) );
			if ( 0 == $dentario_columns ) {
				$dentario_columns = min( 6, max( 1, dentario_tags_count( $dentario_widgets_output, 'aside' ) ) );
			}
			if ( $dentario_columns > 1 ) {
				$dentario_widgets_output = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $dentario_columns ) . ' widget', $dentario_widgets_output );
			} else {
				$dentario_need_columns = false;
			}
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo ! empty( $dentario_header_wide ) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<?php do_action( 'dentario_action_before_sidebar_wrap', 'header' ); ?>
			<div class="header_widgets_inner widget_area_inner">
				<?php
				if ( ! $dentario_header_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $dentario_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'dentario_action_before_sidebar', 'header' );
				dentario_show_layout( $dentario_widgets_output );
				do_action( 'dentario_action_after_sidebar', 'header' );
				if ( $dentario_need_columns ) {
					?>
					</div>	<!-- /.columns_wrap -->
					<?php
				}
				if ( ! $dentario_header_wide ) {
					?>
					</div>	<!-- /.content_wrap -->
					<?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
			<?php do_action( 'dentario_action_after_sidebar_wrap', 'header' ); ?>
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
