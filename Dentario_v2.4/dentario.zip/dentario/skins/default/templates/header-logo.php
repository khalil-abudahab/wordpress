<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package DENTARIO
 * @since DENTARIO 1.0
 */

$dentario_args = get_query_var( 'dentario_logo_args' );

// Site logo
$dentario_logo_type   = isset( $dentario_args['type'] ) ? $dentario_args['type'] : '';
$dentario_logo_image  = dentario_get_logo_image( $dentario_logo_type );
$dentario_logo_text   = dentario_is_on( dentario_get_theme_option( 'logo_text' ) ) ? get_bloginfo( 'name' ) : '';
$dentario_logo_slogan = get_bloginfo( 'description', 'display' );
if ( ! empty( $dentario_logo_image['logo'] ) || ! empty( $dentario_logo_text ) ) {
	?><a class="sc_layouts_logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php
		if ( ! empty( $dentario_logo_image['logo'] ) ) {
			if ( empty( $dentario_logo_type ) && function_exists( 'the_custom_logo' ) && is_numeric($dentario_logo_image['logo']) && (int) $dentario_logo_image['logo'] > 0 ) {
				the_custom_logo();
			} else {
				$dentario_attr = dentario_getimagesize( $dentario_logo_image['logo'] );
				echo '<img src="' . esc_url( $dentario_logo_image['logo'] ) . '"'
						. ( ! empty( $dentario_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $dentario_logo_image['logo_retina'] ) . ' 2x"' : '' )
						. ' alt="' . esc_attr( $dentario_logo_text ) . '"'
						. ( ! empty( $dentario_attr[3] ) ? ' ' . wp_kses_data( $dentario_attr[3] ) : '' )
						. '>';
			}
		} else {
			dentario_show_layout( dentario_prepare_macros( $dentario_logo_text ), '<span class="logo_text">', '</span>' );
			dentario_show_layout( dentario_prepare_macros( $dentario_logo_slogan ), '<span class="logo_slogan">', '</span>' );
		}
		?>
	</a>
	<?php
}
