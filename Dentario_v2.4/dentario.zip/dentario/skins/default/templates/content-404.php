<article <?php post_class( 'post_item_single post_item_404' ); ?>>
	<div class="post_content">
		<h1 class="page_title"><?php esc_html_e( '404', 'dentario' ); ?></h1>
		<div class="page_info">
			<h2 class="page_subtitle"><?php esc_html_e( 'Page Not Found', 'dentario' ); ?></h2>
			<p class="page_description"><?php echo wp_kses( __( "We're sorry, but <br>something went wrong.", 'dentario' ), 'dentario_kses_content' ); ?></p>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="go_home theme_button"><?php esc_html_e( 'Homepage', 'dentario' ); ?></a>
		</div>

		<?php
		// SVG
		$svg_bg_1 = dentario_get_svg_from_file(dentario_get_file_dir('images/vectors/404-image.svg'));
		$svg_bg = ($svg_bg_1 ? '<span class="svg-center">'.$svg_bg_1.'</span>' : '');
		if(!empty($svg_bg)){ ?>
		<div class="all-svg">
			<?php dentario_show_layout($svg_bg); ?>
		</div>
		<?php }	?>

	</div>
</article>