<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package DENTARIO
 * @since DENTARIO 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap
<?php
$dentario_copyright_scheme = dentario_get_theme_option( 'copyright_scheme' );
if ( ! empty( $dentario_copyright_scheme ) && ! dentario_is_inherit( $dentario_copyright_scheme  ) ) {
	echo ' scheme_' . esc_attr( $dentario_copyright_scheme );
}
?>
				">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text">
			<?php
				$dentario_copyright = dentario_get_theme_option( 'copyright' );
			if ( ! empty( $dentario_copyright ) ) {
				// Replace {{Y}} or {Y} with the current year
				$dentario_copyright = str_replace( array( '{{Y}}', '{Y}' ), date( 'Y' ), $dentario_copyright );
				// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
				$dentario_copyright = dentario_prepare_macros( $dentario_copyright );
				// Display copyright
				echo wp_kses( nl2br( $dentario_copyright ), 'dentario_kses_content' );
			}
			?>
			</div>
		</div>
	</div>
</div>
