<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package DENTARIO
 * @since DENTARIO 1.0.10
 */

// Footer sidebar
$dentario_footer_name    = dentario_get_theme_option( 'footer_widgets' );
$dentario_footer_present = ! dentario_is_off( $dentario_footer_name ) && is_active_sidebar( $dentario_footer_name );
if ( $dentario_footer_present ) {
	dentario_storage_set( 'current_sidebar', 'footer' );
	$dentario_footer_wide = dentario_get_theme_option( 'footer_wide' );
	ob_start();
	if ( is_active_sidebar( $dentario_footer_name ) ) {
		dynamic_sidebar( $dentario_footer_name );
	}
	$dentario_out = trim( ob_get_contents() );
	ob_end_clean();
	if ( ! empty( $dentario_out ) ) {
		$dentario_out          = preg_replace( "/<\\/aside>[\r\n\s]*<aside/", '</aside><aside', $dentario_out );
		$dentario_need_columns = true;   //or check: strpos($dentario_out, 'columns_wrap')===false;
		if ( $dentario_need_columns ) {
			$dentario_columns = max( 0, (int) dentario_get_theme_option( 'footer_columns' ) );			
			if ( 0 == $dentario_columns ) {
				$dentario_columns = min( 4, max( 1, dentario_tags_count( $dentario_out, 'aside' ) ) );
			}
			if ( $dentario_columns > 1 ) {
				$dentario_out = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $dentario_columns ) . ' widget', $dentario_out );
			} else {
				$dentario_need_columns = false;
			}
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo ! empty( $dentario_footer_wide ) ? ' footer_fullwidth' : ''; ?> sc_layouts_row sc_layouts_row_type_normal">
			<?php do_action( 'dentario_action_before_sidebar_wrap', 'footer' ); ?>
			<div class="footer_widgets_inner widget_area_inner">
				<?php
				if ( ! $dentario_footer_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $dentario_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'dentario_action_before_sidebar', 'footer' );
				dentario_show_layout( $dentario_out );
				do_action( 'dentario_action_after_sidebar', 'footer' );
				if ( $dentario_need_columns ) {
					?>
					</div><!-- /.columns_wrap -->
					<?php
				}
				if ( ! $dentario_footer_wide ) {
					?>
					</div><!-- /.content_wrap -->
					<?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
			<?php do_action( 'dentario_action_after_sidebar_wrap', 'footer' ); ?>
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
