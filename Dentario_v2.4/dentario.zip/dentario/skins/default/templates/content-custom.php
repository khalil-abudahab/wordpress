<?php
/**
 * The custom template to display the content
 *
 * Used for index/archive/search.
 *
 * @package DENTARIO
 * @since DENTARIO 1.0.50
 */

$dentario_template_args = get_query_var( 'dentario_template_args' );
if ( is_array( $dentario_template_args ) ) {
	$dentario_columns    = empty( $dentario_template_args['columns'] ) ? 2 : max( 1, $dentario_template_args['columns'] );
	$dentario_blog_style = array( $dentario_template_args['type'], $dentario_columns );
} else {
	$dentario_template_args = array();
	$dentario_blog_style = explode( '_', dentario_get_theme_option( 'blog_style' ) );
	$dentario_columns    = empty( $dentario_blog_style[1] ) ? 2 : max( 1, $dentario_blog_style[1] );
}
$dentario_blog_id       = dentario_get_custom_blog_id( join( '_', $dentario_blog_style ) );
$dentario_blog_style[0] = str_replace( 'blog-custom-', '', $dentario_blog_style[0] );
$dentario_expanded      = ! dentario_sidebar_present() && dentario_get_theme_option( 'expand_content' ) == 'expand';
$dentario_components    = ! empty( $dentario_template_args['meta_parts'] )
							? ( is_array( $dentario_template_args['meta_parts'] )
								? join( ',', $dentario_template_args['meta_parts'] )
								: $dentario_template_args['meta_parts']
								)
							: dentario_array_get_keys_by_value( dentario_get_theme_option( 'meta_parts' ) );
$dentario_post_format   = get_post_format();
$dentario_post_format   = empty( $dentario_post_format ) ? 'standard' : str_replace( 'post-format-', '', $dentario_post_format );

$dentario_blog_meta     = dentario_get_custom_layout_meta( $dentario_blog_id );
$dentario_custom_style  = ! empty( $dentario_blog_meta['scripts_required'] ) ? $dentario_blog_meta['scripts_required'] : 'none';

if ( ! empty( $dentario_template_args['slider'] ) || $dentario_columns > 1 || ! dentario_is_off( $dentario_custom_style ) ) {
	?><div class="
		<?php
		if ( ! empty( $dentario_template_args['slider'] ) ) {
			echo 'slider-slide swiper-slide';
		} else {
			echo esc_attr( ( dentario_is_off( $dentario_custom_style ) ? 'column' : sprintf( '%1$s_item %1$s_item', $dentario_custom_style ) ) . "-1_{$dentario_columns}" );
		}
		?>
	">
	<?php
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
			'post_item post_item_container post_format_' . esc_attr( $dentario_post_format )
					. ' post_layout_custom post_layout_custom_' . esc_attr( $dentario_columns )
					. ' post_layout_' . esc_attr( $dentario_blog_style[0] )
					. ' post_layout_' . esc_attr( $dentario_blog_style[0] ) . '_' . esc_attr( $dentario_columns )
					. ( ! dentario_is_off( $dentario_custom_style )
						? ' post_layout_' . esc_attr( $dentario_custom_style )
							. ' post_layout_' . esc_attr( $dentario_custom_style ) . '_' . esc_attr( $dentario_columns )
						: ''
						)
		);
	dentario_add_blog_animation( $dentario_template_args );
	?>
>
	<?php
	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}
	// Custom layout
	do_action( 'dentario_action_show_layout', $dentario_blog_id, get_the_ID() );
	?>
</article><?php
if ( ! empty( $dentario_template_args['slider'] ) || $dentario_columns > 1 || ! dentario_is_off( $dentario_custom_style ) ) {
	?></div><?php
	// Need opening PHP-tag above just after </div>, because <div> is a inline-block element (used as column)!
}
