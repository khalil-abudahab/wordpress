<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package DENTARIO
 * @since DENTARIO 1.0
 */

$dentario_template_args = get_query_var( 'dentario_template_args' );
if ( is_array( $dentario_template_args ) ) {
	$dentario_columns    = empty( $dentario_template_args['columns'] ) ? 2 : max( 1, $dentario_template_args['columns'] );
	$dentario_blog_style = array( $dentario_template_args['type'], $dentario_columns );
    $dentario_columns_class = dentario_get_column_class( 1, $dentario_columns, ! empty( $dentario_template_args['columns_tablet']) ? $dentario_template_args['columns_tablet'] : '', ! empty($dentario_template_args['columns_mobile']) ? $dentario_template_args['columns_mobile'] : '' );
} else {
	$dentario_template_args = array();
	$dentario_blog_style = explode( '_', dentario_get_theme_option( 'blog_style' ) );
	$dentario_columns    = empty( $dentario_blog_style[1] ) ? 2 : max( 1, $dentario_blog_style[1] );
    $dentario_columns_class = dentario_get_column_class( 1, $dentario_columns );
}

$dentario_post_format = get_post_format();
$dentario_post_format = empty( $dentario_post_format ) ? 'standard' : str_replace( 'post-format-', '', $dentario_post_format );

?><div class="
<?php
if ( ! empty( $dentario_template_args['slider'] ) ) {
	echo ' slider-slide swiper-slide';
} else {
	echo ( dentario_is_blog_style_use_masonry( $dentario_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $dentario_columns ) : esc_attr( $dentario_columns_class ));
}
?>
"><article id="post-<?php the_ID(); ?>" 
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $dentario_post_format )
		. ' post_layout_portfolio'
		. ' post_layout_portfolio_' . esc_attr( $dentario_columns )
		. ( 'portfolio' != $dentario_blog_style[0] ? ' ' . esc_attr( $dentario_blog_style[0] )  . '_' . esc_attr( $dentario_columns ) : '' )
	);
	dentario_add_blog_animation( $dentario_template_args );
	?>
>
<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	$dentario_hover   = ! empty( $dentario_template_args['hover'] ) && ! dentario_is_inherit( $dentario_template_args['hover'] )
								? $dentario_template_args['hover']
								: dentario_get_theme_option( 'image_hover' );

	if ( 'dots' == $dentario_hover ) {
		$dentario_post_link = empty( $dentario_template_args['no_links'] )
								? ( ! empty( $dentario_template_args['link'] )
									? $dentario_template_args['link']
									: get_permalink()
									)
								: '';
		$dentario_target    = ! empty( $dentario_post_link ) && dentario_is_external_url( $dentario_post_link )
								? ' target="_blank" rel="nofollow"'
								: '';
	}
	
	// Meta parts
	$dentario_components = ! empty( $dentario_template_args['meta_parts'] )
							? ( is_array( $dentario_template_args['meta_parts'] )
								? $dentario_template_args['meta_parts']
								: explode( ',', $dentario_template_args['meta_parts'] )
								)
							: dentario_array_get_keys_by_value( dentario_get_theme_option( 'meta_parts' ) );

	// Featured image
	dentario_show_post_featured( apply_filters( 'dentario_filter_args_featured',
        array(
			'hover'         => $dentario_hover,
			'no_links'      => ! empty( $dentario_template_args['no_links'] ),
			'thumb_size'    => ! empty( $dentario_template_args['thumb_size'] )
								? $dentario_template_args['thumb_size']
								: dentario_get_thumb_size(
									dentario_is_blog_style_use_masonry( $dentario_blog_style[0] )
										? (	strpos( dentario_get_theme_option( 'body_style' ), 'full' ) !== false || $dentario_columns < 3
											? 'masonry-big'
											: 'masonry'
											)
										: (	strpos( dentario_get_theme_option( 'body_style' ), 'full' ) !== false || $dentario_columns < 3
											? 'square'
											: 'square'
											)
								),
			'thumb_bg' => dentario_is_blog_style_use_masonry( $dentario_blog_style[0] ) ? false : true,
			'show_no_image' => true,
			'meta_parts'    => $dentario_components,
			'class'         => 'dots' == $dentario_hover ? 'hover_with_info' : '',
			'post_info'     => 'dots' == $dentario_hover
										? '<div class="post_info"><h5 class="post_title">'
											. ( ! empty( $dentario_post_link )
												? '<a href="' . esc_url( $dentario_post_link ) . '"' . ( ! empty( $target ) ? $target : '' ) . '>'
												: ''
												)
												. esc_html( get_the_title() ) 
											. ( ! empty( $dentario_post_link )
												? '</a>'
												: ''
												)
											. '</h5></div>'
										: '',
            'thumb_ratio'   => 'info' == $dentario_hover ?  '100:102' : '',
        ),
        'content-portfolio',
        $dentario_template_args
    ) );
	?>
</article></div><?php
// Need opening PHP-tag above, because <article> is a inline-block element (used as column)!