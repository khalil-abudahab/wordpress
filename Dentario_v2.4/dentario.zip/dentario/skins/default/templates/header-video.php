<?php
/**
 * The template to display the background video in the header
 *
 * @package DENTARIO
 * @since DENTARIO 1.0.14
 */
$dentario_header_video = dentario_get_header_video();
$dentario_embed_video  = '';
if ( ! empty( $dentario_header_video ) && ! dentario_is_from_uploads( $dentario_header_video ) ) {
	if ( dentario_is_youtube_url( $dentario_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $dentario_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php dentario_show_layout( dentario_get_embed_video( $dentario_header_video ) ); ?></div>
		<?php
	}
}
