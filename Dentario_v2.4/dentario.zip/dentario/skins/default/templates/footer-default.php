<?php
/**
 * The template to display default site footer
 *
 * @package DENTARIO
 * @since DENTARIO 1.0.10
 */

?>
<footer class="footer_wrap footer_default
<?php
$dentario_footer_scheme = dentario_get_theme_option( 'footer_scheme' );
if ( ! empty( $dentario_footer_scheme ) && ! dentario_is_inherit( $dentario_footer_scheme  ) ) {
	echo ' scheme_' . esc_attr( $dentario_footer_scheme );
}
?>
				">
	<?php

	// Footer widgets area
	get_template_part( apply_filters( 'dentario_filter_get_template_part', 'templates/footer-widgets' ) );

	// Logo
	get_template_part( apply_filters( 'dentario_filter_get_template_part', 'templates/footer-logo' ) );

	// Socials
	get_template_part( apply_filters( 'dentario_filter_get_template_part', 'templates/footer-socials' ) );

	// Copyright area
	get_template_part( apply_filters( 'dentario_filter_get_template_part', 'templates/footer-copyright' ) );

	?>
</footer><!-- /.footer_wrap -->
