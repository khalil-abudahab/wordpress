<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package DENTARIO
 * @since DENTARIO 1.0
 */

if ( dentario_sidebar_present() ) {
	
	$dentario_sidebar_type = dentario_get_theme_option( 'sidebar_type' );
	if ( 'custom' == $dentario_sidebar_type && ! dentario_is_layouts_available() ) {
		$dentario_sidebar_type = 'default';
	}
	
	// Catch output to the buffer
	ob_start();
	if ( 'default' == $dentario_sidebar_type ) {
		// Default sidebar with widgets
		$dentario_sidebar_name = dentario_get_theme_option( 'sidebar_widgets' );
		dentario_storage_set( 'current_sidebar', 'sidebar' );
		if ( is_active_sidebar( $dentario_sidebar_name ) ) {
			dynamic_sidebar( $dentario_sidebar_name );
		}
	} else {
		// Custom sidebar from Layouts Builder
		$dentario_sidebar_id = dentario_get_custom_sidebar_id();
		do_action( 'dentario_action_show_layout', $dentario_sidebar_id );
	}
	$dentario_out = trim( ob_get_contents() );
	ob_end_clean();
	
	// If any html is present - display it
	if ( ! empty( $dentario_out ) ) {
		$dentario_sidebar_position    = dentario_get_theme_option( 'sidebar_position' );
		$dentario_sidebar_position_ss = dentario_get_theme_option( 'sidebar_position_ss', 'below' );
		?>
		<div class="sidebar widget_area
			<?php
			echo ' ' . esc_attr( $dentario_sidebar_position );
			echo ' sidebar_' . esc_attr( $dentario_sidebar_position_ss );
			echo ' sidebar_' . esc_attr( $dentario_sidebar_type );

			$dentario_sidebar_scheme = apply_filters( 'dentario_filter_sidebar_scheme', dentario_get_theme_option( 'sidebar_scheme', 'inherit' ) );
			if ( ! empty( $dentario_sidebar_scheme ) && ! dentario_is_inherit( $dentario_sidebar_scheme ) && 'custom' != $dentario_sidebar_type ) {
				echo ' scheme_' . esc_attr( $dentario_sidebar_scheme );
			}
			?>
		" role="complementary">
			<?php

			// Skip link anchor to fast access to the sidebar from keyboard
			?>
			<a id="sidebar_skip_link_anchor" class="dentario_skip_link_anchor" href="#"></a>
			<?php

			do_action( 'dentario_action_before_sidebar_wrap', 'sidebar' );

			// Button to show/hide sidebar on mobile
			if ( in_array( $dentario_sidebar_position_ss, array( 'above', 'float' ) ) ) {
				$dentario_title = apply_filters( 'dentario_filter_sidebar_control_title', 'float' == $dentario_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'dentario' ) : '' );
				$dentario_text  = apply_filters( 'dentario_filter_sidebar_control_text', 'above' == $dentario_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'dentario' ) : '' );
				?>
				<a href="#" class="sidebar_control" title="<?php echo esc_attr( $dentario_title ); ?>"><?php echo esc_html( $dentario_text ); ?></a>
				<?php
			}
			?>
			<div class="sidebar_inner">
				<?php
				do_action( 'dentario_action_before_sidebar', 'sidebar' );
				dentario_show_layout( preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $dentario_out ) );
				do_action( 'dentario_action_after_sidebar', 'sidebar' );
				?>
			</div>
			<?php

			do_action( 'dentario_action_after_sidebar_wrap', 'sidebar' );

			?>
		</div>
		<div class="clearfix"></div>
		<?php
	}
}
