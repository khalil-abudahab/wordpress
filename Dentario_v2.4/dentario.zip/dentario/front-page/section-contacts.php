<div class="front_page_section front_page_section_contacts<?php
	$dentario_scheme = dentario_get_theme_option( 'front_page_contacts_scheme' );
	if ( ! empty( $dentario_scheme ) && ! dentario_is_inherit( $dentario_scheme ) ) {
		echo ' scheme_' . esc_attr( $dentario_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( dentario_get_theme_option( 'front_page_contacts_paddings' ) );
	if ( dentario_get_theme_option( 'front_page_contacts_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$dentario_css      = '';
		$dentario_bg_image = dentario_get_theme_option( 'front_page_contacts_bg_image' );
		if ( ! empty( $dentario_bg_image ) ) {
			$dentario_css .= 'background-image: url(' . esc_url( dentario_get_attachment_url( $dentario_bg_image ) ) . ');';
		}
		if ( ! empty( $dentario_css ) ) {
			echo ' style="' . esc_attr( $dentario_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$dentario_anchor_icon = dentario_get_theme_option( 'front_page_contacts_anchor_icon' );
	$dentario_anchor_text = dentario_get_theme_option( 'front_page_contacts_anchor_text' );
if ( ( ! empty( $dentario_anchor_icon ) || ! empty( $dentario_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_contacts"'
									. ( ! empty( $dentario_anchor_icon ) ? ' icon="' . esc_attr( $dentario_anchor_icon ) . '"' : '' )
									. ( ! empty( $dentario_anchor_text ) ? ' title="' . esc_attr( $dentario_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_contacts_inner
	<?php
	if ( dentario_get_theme_option( 'front_page_contacts_fullheight' ) ) {
		echo ' dentario-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$dentario_css      = '';
			$dentario_bg_mask  = dentario_get_theme_option( 'front_page_contacts_bg_mask' );
			$dentario_bg_color_type = dentario_get_theme_option( 'front_page_contacts_bg_color_type' );
			if ( 'custom' == $dentario_bg_color_type ) {
				$dentario_bg_color = dentario_get_theme_option( 'front_page_contacts_bg_color' );
			} elseif ( 'scheme_bg_color' == $dentario_bg_color_type ) {
				$dentario_bg_color = dentario_get_scheme_color( 'bg_color', $dentario_scheme );
			} else {
				$dentario_bg_color = '';
			}
			if ( ! empty( $dentario_bg_color ) && $dentario_bg_mask > 0 ) {
				$dentario_css .= 'background-color: ' . esc_attr(
					1 == $dentario_bg_mask ? $dentario_bg_color : dentario_hex2rgba( $dentario_bg_color, $dentario_bg_mask )
				) . ';';
			}
			if ( ! empty( $dentario_css ) ) {
				echo ' style="' . esc_attr( $dentario_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_contacts_content_wrap content_wrap">
			<?php

			// Title and description
			$dentario_caption     = dentario_get_theme_option( 'front_page_contacts_caption' );
			$dentario_description = dentario_get_theme_option( 'front_page_contacts_description' );
			if ( ! empty( $dentario_caption ) || ! empty( $dentario_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				// Caption
				if ( ! empty( $dentario_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					?>
					<h2 class="front_page_section_caption front_page_section_contacts_caption front_page_block_<?php echo ! empty( $dentario_caption ) ? 'filled' : 'empty'; ?>">
					<?php
						echo wp_kses( $dentario_caption, 'dentario_kses_content' );
					?>
					</h2>
					<?php
				}

				// Description
				if ( ! empty( $dentario_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					?>
					<div class="front_page_section_description front_page_section_contacts_description front_page_block_<?php echo ! empty( $dentario_description ) ? 'filled' : 'empty'; ?>">
					<?php
						echo wp_kses( wpautop( $dentario_description ), 'dentario_kses_content' );
					?>
					</div>
					<?php
				}
			}

			// Content (text)
			$dentario_content = dentario_get_theme_option( 'front_page_contacts_content' );
			$dentario_layout  = dentario_get_theme_option( 'front_page_contacts_layout' );
			if ( 'columns' == $dentario_layout && ( ! empty( $dentario_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				<div class="front_page_section_columns front_page_section_contacts_columns columns_wrap">
					<div class="column-1_3">
				<?php
			}

			if ( ( ! empty( $dentario_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				<div class="front_page_section_content front_page_section_contacts_content front_page_block_<?php echo ! empty( $dentario_content ) ? 'filled' : 'empty'; ?>">
					<?php
					echo wp_kses( $dentario_content, 'dentario_kses_content' );
					?>
				</div>
				<?php
			}

			if ( 'columns' == $dentario_layout && ( ! empty( $dentario_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				</div><div class="column-2_3">
				<?php
			}

			// Shortcode output
			$dentario_sc = dentario_get_theme_option( 'front_page_contacts_shortcode' );
			if ( ! empty( $dentario_sc ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_output front_page_section_contacts_output front_page_block_<?php echo ! empty( $dentario_sc ) ? 'filled' : 'empty'; ?>">
					<?php
					dentario_show_layout( do_shortcode( $dentario_sc ) );
					?>
				</div>
				<?php
			}

			if ( 'columns' == $dentario_layout && ( ! empty( $dentario_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				</div></div>
				<?php
			}
			?>

		</div>
	</div>
</div>
