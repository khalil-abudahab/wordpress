<?php
$dentario_woocommerce_sc = dentario_get_theme_option( 'front_page_woocommerce_products' );
if ( ! empty( $dentario_woocommerce_sc ) ) {
	?><div class="front_page_section front_page_section_woocommerce<?php
		$dentario_scheme = dentario_get_theme_option( 'front_page_woocommerce_scheme' );
		if ( ! empty( $dentario_scheme ) && ! dentario_is_inherit( $dentario_scheme ) ) {
			echo ' scheme_' . esc_attr( $dentario_scheme );
		}
		echo ' front_page_section_paddings_' . esc_attr( dentario_get_theme_option( 'front_page_woocommerce_paddings' ) );
		if ( dentario_get_theme_option( 'front_page_woocommerce_stack' ) ) {
			echo ' sc_stack_section_on';
		}
	?>"
			<?php
			$dentario_css      = '';
			$dentario_bg_image = dentario_get_theme_option( 'front_page_woocommerce_bg_image' );
			if ( ! empty( $dentario_bg_image ) ) {
				$dentario_css .= 'background-image: url(' . esc_url( dentario_get_attachment_url( $dentario_bg_image ) ) . ');';
			}
			if ( ! empty( $dentario_css ) ) {
				echo ' style="' . esc_attr( $dentario_css ) . '"';
			}
			?>
	>
	<?php
		// Add anchor
		$dentario_anchor_icon = dentario_get_theme_option( 'front_page_woocommerce_anchor_icon' );
		$dentario_anchor_text = dentario_get_theme_option( 'front_page_woocommerce_anchor_text' );
		if ( ( ! empty( $dentario_anchor_icon ) || ! empty( $dentario_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
			echo do_shortcode(
				'[trx_sc_anchor id="front_page_section_woocommerce"'
											. ( ! empty( $dentario_anchor_icon ) ? ' icon="' . esc_attr( $dentario_anchor_icon ) . '"' : '' )
											. ( ! empty( $dentario_anchor_text ) ? ' title="' . esc_attr( $dentario_anchor_text ) . '"' : '' )
											. ']'
			);
		}
	?>
		<div class="front_page_section_inner front_page_section_woocommerce_inner
			<?php
			if ( dentario_get_theme_option( 'front_page_woocommerce_fullheight' ) ) {
				echo ' dentario-full-height sc_layouts_flex sc_layouts_columns_middle';
			}
			?>
				"
				<?php
				$dentario_css      = '';
				$dentario_bg_mask  = dentario_get_theme_option( 'front_page_woocommerce_bg_mask' );
				$dentario_bg_color_type = dentario_get_theme_option( 'front_page_woocommerce_bg_color_type' );
				if ( 'custom' == $dentario_bg_color_type ) {
					$dentario_bg_color = dentario_get_theme_option( 'front_page_woocommerce_bg_color' );
				} elseif ( 'scheme_bg_color' == $dentario_bg_color_type ) {
					$dentario_bg_color = dentario_get_scheme_color( 'bg_color', $dentario_scheme );
				} else {
					$dentario_bg_color = '';
				}
				if ( ! empty( $dentario_bg_color ) && $dentario_bg_mask > 0 ) {
					$dentario_css .= 'background-color: ' . esc_attr(
						1 == $dentario_bg_mask ? $dentario_bg_color : dentario_hex2rgba( $dentario_bg_color, $dentario_bg_mask )
					) . ';';
				}
				if ( ! empty( $dentario_css ) ) {
					echo ' style="' . esc_attr( $dentario_css ) . '"';
				}
				?>
		>
			<div class="front_page_section_content_wrap front_page_section_woocommerce_content_wrap content_wrap woocommerce">
				<?php
				// Content wrap with title and description
				$dentario_caption     = dentario_get_theme_option( 'front_page_woocommerce_caption' );
				$dentario_description = dentario_get_theme_option( 'front_page_woocommerce_description' );
				if ( ! empty( $dentario_caption ) || ! empty( $dentario_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					// Caption
					if ( ! empty( $dentario_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
						?>
						<h2 class="front_page_section_caption front_page_section_woocommerce_caption front_page_block_<?php echo ! empty( $dentario_caption ) ? 'filled' : 'empty'; ?>">
						<?php
							echo wp_kses( $dentario_caption, 'dentario_kses_content' );
						?>
						</h2>
						<?php
					}

					// Description (text)
					if ( ! empty( $dentario_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
						?>
						<div class="front_page_section_description front_page_section_woocommerce_description front_page_block_<?php echo ! empty( $dentario_description ) ? 'filled' : 'empty'; ?>">
						<?php
							echo wp_kses( wpautop( $dentario_description ), 'dentario_kses_content' );
						?>
						</div>
						<?php
					}
				}

				// Content (widgets)
				?>
				<div class="front_page_section_output front_page_section_woocommerce_output list_products shop_mode_thumbs">
					<?php
					if ( 'products' == $dentario_woocommerce_sc ) {
						$dentario_woocommerce_sc_ids      = dentario_get_theme_option( 'front_page_woocommerce_products_per_page' );
						$dentario_woocommerce_sc_per_page = count( explode( ',', $dentario_woocommerce_sc_ids ) );
					} else {
						$dentario_woocommerce_sc_per_page = max( 1, (int) dentario_get_theme_option( 'front_page_woocommerce_products_per_page' ) );
					}
					$dentario_woocommerce_sc_columns = max( 1, min( $dentario_woocommerce_sc_per_page, (int) dentario_get_theme_option( 'front_page_woocommerce_products_columns' ) ) );
					echo do_shortcode(
						"[{$dentario_woocommerce_sc}"
										. ( 'products' == $dentario_woocommerce_sc
												? ' ids="' . esc_attr( $dentario_woocommerce_sc_ids ) . '"'
												: '' )
										. ( 'product_category' == $dentario_woocommerce_sc
												? ' category="' . esc_attr( dentario_get_theme_option( 'front_page_woocommerce_products_categories' ) ) . '"'
												: '' )
										. ( 'best_selling_products' != $dentario_woocommerce_sc
												? ' orderby="' . esc_attr( dentario_get_theme_option( 'front_page_woocommerce_products_orderby' ) ) . '"'
													. ' order="' . esc_attr( dentario_get_theme_option( 'front_page_woocommerce_products_order' ) ) . '"'
												: '' )
										. ' per_page="' . esc_attr( $dentario_woocommerce_sc_per_page ) . '"'
										. ' columns="' . esc_attr( $dentario_woocommerce_sc_columns ) . '"'
						. ']'
					);
					?>
				</div>
			</div>
		</div>
	</div>
	<?php
}
